﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace WindowsFormsApp1
{
    public partial class Platech : Form
    {
        public static string id;
        public Platech()
        {
            InitializeComponent();
        }

        private void Platech_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "kworkDataSet4.client". При необходимости она может быть перемещена или удалена.
            this.clientTableAdapter2.Fill(this.kworkDataSet4.client);
           


        }

        private void button1_Click(object sender, EventArgs e)
        {



            this.panel1.Controls.Clear();
            Dobavit zakaz_vrb = new Dobavit() { Dock = DockStyle.Fill, TopLevel = false, TopMost = true };
            zakaz_vrb.FormBorderStyle = FormBorderStyle.None;
            this.panel1.Controls.Add(zakaz_vrb);
            zakaz_vrb.Show();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            this.clientTableAdapter2.Fill(this.kworkDataSet4.client);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.panel1.Controls.Clear();
            Form2 zakaz_vrb = new Form2() { Dock = DockStyle.Fill, TopLevel = false, TopMost = true };
            zakaz_vrb.FormBorderStyle = FormBorderStyle.None;
            this.panel1.Controls.Add(zakaz_vrb);
            zakaz_vrb.Show();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 10)
            {
                id = dataGridView1.CurrentRow.Cells[0].Value.ToString();
                this.panel1.Controls.Clear();
                Form2 zakaz_vrb = new Form2() { Dock = DockStyle.Fill, TopLevel = false, TopMost = true };
                zakaz_vrb.FormBorderStyle = FormBorderStyle.None;
                this.panel1.Controls.Add(zakaz_vrb);
                zakaz_vrb.Show();
              
            }
        }
    }
}
