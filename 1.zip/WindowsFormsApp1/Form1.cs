﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    
    public partial class Form1 : Form
    {
        public static string name;
        public static SqlConnection connnection = new SqlConnection(@"Data source = LAPTOP-RM0GSJB7;Initial catalog = kwork;Integrated security = true");
        public Form1()
        {
            InitializeComponent();

            label7.Visible = false;
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            Reg reg = new Reg();    
            reg.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            connnection.Open();
            var Password = txbx_password.Text;
            var login = txbx_login.Text;    
            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter();
            DataTable dt = new DataTable();
            SqlCommand cmd = new SqlCommand($"Select * from Staff where login = '{login}' and Password = '{Password}'");
            cmd.Connection = connnection;
            sqlDataAdapter.SelectCommand = cmd;
            sqlDataAdapter.Fill( dt );
            if(dt.Rows.Count > 0)
            {
                name = dt.Rows[0]["Name"].ToString();
                this.Hide();
                Osnova osnova = new Osnova();
                osnova.Show();
            }    
            else 
                label7.Visible=true;

            connnection.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
