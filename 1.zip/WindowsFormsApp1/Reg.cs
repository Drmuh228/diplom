﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Reg : Form
    {
        public Reg()
        {
            InitializeComponent();
            label7.Visible = false;
        }

        private void Reg_Load(object sender, EventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Close();
            Form1 form1 = new Form1();
            form1.ShowDialog();
        }

        private void btn_reg_Click(object sender, EventArgs e)
        {
          
            //Код регистрации
            if (txbx_password1.Text == txbx_password2.Text)
            {
                Form1.connnection.Open();
                SqlCommand command = new SqlCommand(@"Insert into Staff(Name,Login,Password,Email) values (@Name,@Login,@Password,@Email)");
                command.Connection = Form1.connnection;
                command.Parameters.AddWithValue("Name", txbx_FIO.Text);
                command.Parameters.AddWithValue("Login", txbx_login.Text);
                command.Parameters.AddWithValue("Password", txbx_password2.Text);
                command.Parameters.AddWithValue("Email", txbx_email.Text);
                command.ExecuteNonQuery();
                Form1.connnection.Close();
                this.Close();
                Form1 form1 = new Form1();
                form1.ShowDialog();

            }
            else
                label7.Visible = true;
        }
    }
}
