﻿namespace WindowsFormsApp1
{
    partial class Setting
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.kworkDataSet = new WindowsFormsApp1.kworkDataSet();
            this.surceBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.surceTableAdapter = new WindowsFormsApp1.kworkDataSetTableAdapters.SurceTableAdapter();
            this.kworkDataSet1 = new WindowsFormsApp1.kworkDataSet();
            this.surceBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.nameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.summDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.surceBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.kworkDataSet11 = new WindowsFormsApp1.kworkDataSet1();
            this.surceTableAdapter1 = new WindowsFormsApp1.kworkDataSet1TableAdapters.SurceTableAdapter();
            this.panel1 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.kworkDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.surceBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kworkDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.surceBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.surceBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kworkDataSet11)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(293, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(172, 37);
            this.label1.TabIndex = 0;
            this.label1.Text = "Настройки";
            // 
            // kworkDataSet
            // 
            this.kworkDataSet.DataSetName = "kworkDataSet";
            this.kworkDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // surceBindingSource
            // 
            this.surceBindingSource.DataMember = "Surce";
            this.surceBindingSource.DataSource = this.kworkDataSet;
            // 
            // surceTableAdapter
            // 
            this.surceTableAdapter.ClearBeforeFill = true;
            // 
            // kworkDataSet1
            // 
            this.kworkDataSet1.DataSetName = "kworkDataSet";
            this.kworkDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // surceBindingSource1
            // 
            this.surceBindingSource1.DataMember = "Surce";
            this.surceBindingSource1.DataSource = this.kworkDataSet;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.nameDataGridViewTextBoxColumn,
            this.summDataGridViewTextBoxColumn,
            this.Column1});
            this.dataGridView1.Cursor = System.Windows.Forms.Cursors.SizeAll;
            this.dataGridView1.DataSource = this.surceBindingSource2;
            this.dataGridView1.Location = new System.Drawing.Point(12, 49);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.Size = new System.Drawing.Size(755, 230);
            this.dataGridView1.TabIndex = 4;
            this.dataGridView1.TabStop = false;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick_1);
            // 
            // nameDataGridViewTextBoxColumn
            // 
            this.nameDataGridViewTextBoxColumn.DataPropertyName = "Name";
            this.nameDataGridViewTextBoxColumn.HeaderText = "Название";
            this.nameDataGridViewTextBoxColumn.Name = "nameDataGridViewTextBoxColumn";
            this.nameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // summDataGridViewTextBoxColumn
            // 
            this.summDataGridViewTextBoxColumn.DataPropertyName = "Summ";
            this.summDataGridViewTextBoxColumn.HeaderText = "Стоимость";
            this.summDataGridViewTextBoxColumn.Name = "summDataGridViewTextBoxColumn";
            this.summDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Изменить";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            this.Column1.Text = "Изменить";
            this.Column1.ToolTipText = "Изменить";
            this.Column1.UseColumnTextForButtonValue = true;
            // 
            // surceBindingSource2
            // 
            this.surceBindingSource2.DataMember = "Surce";
            this.surceBindingSource2.DataSource = this.kworkDataSet11;
            // 
            // kworkDataSet11
            // 
            this.kworkDataSet11.DataSetName = "kworkDataSet1";
            this.kworkDataSet11.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // surceTableAdapter1
            // 
            this.surceTableAdapter1.ClearBeforeFill = true;
            // 
            // panel1
            // 
            this.panel1.Location = new System.Drawing.Point(206, 285);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(367, 222);
            this.panel1.TabIndex = 5;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // Setting
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(827, 519);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Setting";
            this.Text = "Setting";
            this.Load += new System.EventHandler(this.Setting_Load);
            ((System.ComponentModel.ISupportInitialize)(this.kworkDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.surceBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kworkDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.surceBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.surceBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kworkDataSet11)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private kworkDataSet kworkDataSet;
        private System.Windows.Forms.BindingSource surceBindingSource;
        private kworkDataSetTableAdapters.SurceTableAdapter surceTableAdapter;
        private kworkDataSet kworkDataSet1;
        private System.Windows.Forms.BindingSource surceBindingSource1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private kworkDataSet1 kworkDataSet11;
        private System.Windows.Forms.BindingSource surceBindingSource2;
        private kworkDataSet1TableAdapters.SurceTableAdapter surceTableAdapter1;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn summDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewButtonColumn Column1;
        private System.Windows.Forms.Panel panel1;
    }
}