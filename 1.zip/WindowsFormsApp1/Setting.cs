﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Setting : Form
    {
        public static string name;
        public static string value;
        public Setting()
        {
            InitializeComponent();
        }

        private void Setting_Load(object sender, EventArgs e)
        {

            // TODO: данная строка кода позволяет загрузить данные в таблицу "kworkDataSet11.Surce". При необходимости она может быть перемещена или удалена.
            this.surceTableAdapter1.Fill(this.kworkDataSet11.Surce);
          

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {
            if(e.ColumnIndex == 2) 
            {
                name = dataGridView1.CurrentRow.Cells[0].Value.ToString();
                value = dataGridView1.CurrentRow.Cells[1].Value.ToString();
                this.panel1.Controls.Clear();
                Lam zakaz_vrb = new Lam() { Dock = DockStyle.Fill, TopLevel = false, TopMost = true };
                zakaz_vrb.FormBorderStyle = FormBorderStyle.None;
                this.panel1.Controls.Add(zakaz_vrb);
                zakaz_vrb.Show();
                this.surceTableAdapter1.Fill(this.kworkDataSet11.Surce);
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
                 this.surceTableAdapter1.Fill(this.kworkDataSet11.Surce);
        }
    }
}
