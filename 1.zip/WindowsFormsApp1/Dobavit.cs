﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace WindowsFormsApp1
{
   
    public partial class Dobavit : Form
    {
        public static string a;
        public static string a1;
        public static string a2;
        public static string a3;
        public static string a4 ;
        public static string a5 = "В работе";
        public static int a6;
        public Dobavit()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1.connnection.Open();
            SqlCommand command = new SqlCommand(@"Insert into client(Name,NomerAuto,Model,Color,Summa,date,Status,Zakaz,dataOver) values (@Name,@NomerAuto,@Model,@Color,@Summa,@date,@Status,@Zakaz,@dataOver)");
            command.Connection = Form1.connnection;
            command.Parameters.AddWithValue("Name", textBox1.Text);
            command.Parameters.AddWithValue("NomerAuto", textBox3.Text);
            command.Parameters.AddWithValue("Model", textBox5.Text);
            command.Parameters.AddWithValue("Color", textBox2.Text);
            command.Parameters.AddWithValue("Summa", Convert.ToInt32(a6));
            command.Parameters.AddWithValue("date", DateTime.Now);
            command.Parameters.AddWithValue("Status", a5);
            command.Parameters.AddWithValue("Zakaz", a4);
            command.Parameters.AddWithValue("dataOver", dateTimePicker1.Value.ToShortDateString());
            command.ExecuteNonQuery();
            Form1.connnection.Close();
            this.Close();
        
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Dobavit_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "kworkDataSet3.Surce". При необходимости она может быть перемещена или удалена.
            this.surceTableAdapter1.Fill(this.kworkDataSet3.Surce);

            // TODO: данная строка кода позволяет загрузить данные в таблицу "kworkDataSet.client". При необходимости она может быть перемещена или удалена.
           // this.clientTableAdapter.Fill(this.kworkDataSet.client);

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string login = button2.Text;
            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter();
            DataTable dt = new DataTable();
            SqlCommand cmd = new SqlCommand($"Select * from Surce where Name = '{login}'");
            cmd.Connection = Form1.connnection;
            sqlDataAdapter.SelectCommand = cmd;
            sqlDataAdapter.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                a = dt.Rows[0]["Summ"].ToString();
            }
            a4 = a4 + button2.Text + "; ";
            a6 = a6 + Convert.ToInt32(a);
            label7.Text = "Стоимость:" + a6 +  "Р";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string login = button4.Text;
            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter();
            DataTable dt = new DataTable();
            SqlCommand cmd = new SqlCommand($"Select * from Surce where Name = '{login}'");
            cmd.Connection = Form1.connnection;
            sqlDataAdapter.SelectCommand = cmd;
            sqlDataAdapter.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                a = dt.Rows[0]["Summ"].ToString();

            }
            a4 = a4 + button4.Text + "; ";
            a6 = a6 + Convert.ToInt32(a);
            label7.Text = "Стоимость:" + a6 + "Р";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string login = button3.Text;
            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter();
            DataTable dt = new DataTable();
            SqlCommand cmd = new SqlCommand($"Select * from Surce where Name = '{login}'");
            cmd.Connection = Form1.connnection;
            sqlDataAdapter.SelectCommand = cmd;
            sqlDataAdapter.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                a = dt.Rows[0]["Summ"].ToString();
            }
            a4 = a4 + button3.Text + "; ";
            a6 = a6 + Convert.ToInt32(a);
            label7.Text = "Стоимость:" + a6 + "Р";
        }

        private void button5_Click(object sender, EventArgs e)
        {
            string login = button5.Text;
            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter();
            DataTable dt = new DataTable();
            SqlCommand cmd = new SqlCommand($"Select * from Surce where Name = '{login}'");
            cmd.Connection = Form1.connnection;
            sqlDataAdapter.SelectCommand = cmd;
            sqlDataAdapter.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                a = dt.Rows[0]["Summ"].ToString();
            }
            a4 = a4 + button5.Text + "; ";
            a6 = a6 + Convert.ToInt32(a);
            label7.Text = "Стоимость:" + a6 + "Р";
        }

        private void button6_Click(object sender, EventArgs e)
        {
            string login = button6.Text;
            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter();
            DataTable dt = new DataTable();
            SqlCommand cmd = new SqlCommand($"Select * from Surce where Name = '{login}'");
            cmd.Connection = Form1.connnection;
            sqlDataAdapter.SelectCommand = cmd;
            sqlDataAdapter.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                a = dt.Rows[0]["Summ"].ToString();
            }
            a4 = a4 + button6.Text + "; ";
            a6 = a6 + Convert.ToInt32(a);
            label7.Text = "Стоимость:" + a6 + "Р";
        }

        private void button7_Click(object sender, EventArgs e)
        {
            string login = button7.Text;
            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter();
            DataTable dt = new DataTable();
            SqlCommand cmd = new SqlCommand($"Select * from Surce where Name = '{login}'");
            cmd.Connection = Form1.connnection;
            sqlDataAdapter.SelectCommand = cmd;
            sqlDataAdapter.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                a = dt.Rows[0]["Summ"].ToString();
            }
            a4 = a4 + button7.Text + "; ";
            a6 = a6 + Convert.ToInt32(a);
            label7.Text = "Стоимость:" + a6 + "Р";
        }

        private void button8_Click(object sender, EventArgs e)
        {
            string login = button8.Text;
            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter();
            DataTable dt = new DataTable();
            SqlCommand cmd = new SqlCommand($"Select * from Surce where Name = '{login}'");
            cmd.Connection = Form1.connnection;
            sqlDataAdapter.SelectCommand = cmd;
            sqlDataAdapter.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                a = dt.Rows[0]["Summ"].ToString();
            }
            a4 = a4 + button8.Text + "; ";
            a6 = a6 + Convert.ToInt32(a);
            label7.Text = "Стоимость:" + a6 + "Р";
        }

        private void button9_Click(object sender, EventArgs e)
        {
            a6 = 0;
            label7.Text = "Стоимость: 0 Руб";
        }
    }
}
