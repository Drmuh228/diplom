﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WindowsFormsApp1
{
    public partial class Zakaz : Form
    {
        public static string status = "Выполнен";
        public Zakaz()
        {
            InitializeComponent();
        }

        private void Zakaz_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "kworkDataSet6.Table1". При необходимости она может быть перемещена или удалена.
            this.table1TableAdapter.Fill(this.kworkDataSet6.Table1);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "kworkDataSet5.client". При необходимости она может быть перемещена или удалена.
            this.clientTableAdapter.Fill(this.kworkDataSet5.client);

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if(e.ColumnIndex == 10)
            {
                Form1.connnection.Open();
                SqlCommand command = new SqlCommand(@"Insert into Table1(Name,NomerAuto,Model,Color,Summa,date,Status,Zakaz,dataOver) values (@Name,@NomerAuto,@Model,@Color,@Summa,@date,@Status,@Zakaz,@dataOver)");
                command.Connection = Form1.connnection;
                command.Parameters.AddWithValue("Name", dataGridView1.CurrentRow.Cells[1].Value.ToString());
                command.Parameters.AddWithValue("NomerAuto", dataGridView1.CurrentRow.Cells[2].Value.ToString());
                command.Parameters.AddWithValue("Model", dataGridView1.CurrentRow.Cells[3].Value.ToString());
                command.Parameters.AddWithValue("Color", dataGridView1.CurrentRow.Cells[4].Value.ToString());
                command.Parameters.AddWithValue("Summa", dataGridView1.CurrentRow.Cells[5].Value.ToString());
                command.Parameters.AddWithValue("date", dataGridView1.CurrentRow.Cells[6].Value.ToString());
                command.Parameters.AddWithValue("Status", status);
                command.Parameters.AddWithValue("Zakaz", dataGridView1.CurrentRow.Cells[8].Value.ToString());
                command.Parameters.AddWithValue("dataOver", dataGridView1.CurrentRow.Cells[9].Value.ToString());
                command.ExecuteNonQuery();
                Form1.connnection.Close();
                Form1.connnection.Open();
                SqlCommand com = new SqlCommand("Delete from [client] where id=" + dataGridView1.CurrentRow.Cells[0].Value.ToString(), Form1.connnection);
                com.ExecuteNonQuery();
                Form1.connnection.Close();
                this.table1TableAdapter.Fill(this.kworkDataSet6.Table1);
                this.clientTableAdapter.Fill(this.kworkDataSet5.client);
            }
            if(e.ColumnIndex == 11)
            {
                Form1.connnection.Open();
                SqlCommand com = new SqlCommand("Delete from [client] where id=" + dataGridView1.CurrentRow.Cells[0].Value.ToString(), Form1.connnection);
                com.ExecuteNonQuery();
                this.clientTableAdapter.Fill(this.kworkDataSet5.client);
                Form1.connnection.Close();
            }
        }
    }
}
